import Home from './index';
export default function () {
  return <Home />;
}
